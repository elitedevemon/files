<!doctype html>
<html lang="en">
<head>
<title>phpMyAdmin</title>
<meta http-equiv="expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Refresh" content="0;url=./public/">
<script>
//<![CDATA[
setTimeout(function() { window.location = decodeURI('./public/'); }, 2000);
//]]>
</script>
</head>
<body>
<script>
//<![CDATA[
document.write('<p>Redirecting to the <a href="./public/">phpMyAdmin interface</a>. If you are not redirected automatically, click the link.</p>');
//]]>
</script>
</body>
</html>
